# Hero image and asset investigation

**Investigation date:** 12 November 2026  
**Creator and Project Lead:** Nivaan Raina

`mars_hero.png` remains unchanged. Its original creator, source, license/permission, and AI-generation status are **unresolved**. No attribution to NASA, an AI model, or an independent artist is supported by the available project evidence.

## File and source evidence

The PNG was read without editing, and its bytes were compared with `ARES/mars_hero.png` inside the original supplied ZIP:

| Observation | Result |
| --- | --- |
| Original ZIP comparison | Byte-for-byte identical |
| File length | 379,601 bytes |
| Dimensions | 600 × 600 pixels |
| PNG format | 8-bit RGBA, non-interlaced |
| SHA-256 | `9e0a81561e1b10c8115df2a2e31fa9ee7f4935e6beec9cbfa6c392970409e16a` |
| Chunk inventory | IHDR, six IDAT chunks, IEND |
| Text/creator/source metadata | No tEXt, iTXt, zTXt or eXIf chunks present |

A source/documentation search found the interface reference in `public_polish.js`, which assigns the image filename and a generic Mars alt description. It supplies no originating URL, creator, license, generation tool, or permission record. The supplied source archive contains no Git history; its retrospective development document does not identify the image's origin. Existing ownership notices and AI-development disclosures are not an image-specific provenance record.

Absence of metadata cannot prove that an image is AI generated, NASA provided, original, or unlicensed. Its appearance was not used to infer origin. No reverse-image attribution or exact external match was established.

## Verified candidate for an owner-approved replacement

A source with a documented origin is NASA Science's [Mars Planet Globe](https://science.nasa.gov/resource/mars-planet-globe/), successfully retrieved through the web reader on 12 November 2026. The page identifies a Viking-orbiter mosaic, credits **NASA/JPL-Caltech**, and offers a 4,798 × 4,798 JPEG download. This is a candidate replacement with a known source, not evidence that the existing PNG comes from that page.

[NASA's Images and Media Guidelines](https://www.nasa.gov/nasa-brand-center/images-and-media/) returned HTTP 200 on the same date. They generally permit educational/informational use of NASA content with source acknowledgment, while distinguishing third-party copyrighted material and prohibiting implied NASA endorsement. NASA marks/logos have separate restrictions. Review the exact asset and current terms for the intended use before adoption; do not describe all NASA-hosted files as universally free of restrictions.

If the owner approves that candidate, record its exact download URL, download date, checksum, retained credit, crop/resize/transparency changes, and source/usage-guideline links. Suggested credit: **“Mars imagery: NASA/JPL-Caltech; Viking orbiter mosaic. Source: NASA Science, Mars Planet Globe.”** If modified, identify the modification. Do not imply that NASA reviewed or endorsed ARES.

A second option is an independently drawn geometric Mars illustration with its creator and creation history recorded. That avoids inventing a NASA origin but still requires a documented rights decision. Neither option has been substituted into the application.

Two guessed NASA resource slugs, `/resource/mars-full-globe/` and `/resource/mars-viking/`, returned HTTP 404; they are not valid replacement citations. The verified page above is a different URL.

## Remaining owner evidence and decisions

- Supply any original image download URL, original file, creator correspondence, generation record, or license/permission.
- If it was AI generated, record the actual tool and material assistance; do not infer them from missing metadata.
- Decide whether to retain the image after rights are established or approve a documented replacement.
- The owner has separately authorized MIT licensing for original ARES software; see ../LICENSE.
The broader register is [../ASSET_PROVENANCE.md](../ASSET_PROVENANCE.md). No image replacement, software-license change, public upload, or deployment occurred as part of this investigation.


## Image replacement — 13 November 2026

The original `mars_hero.png` of unresolved provenance was replaced with a resized NASA/JPL-Caltech Viking Orbiter Mars mosaic.

Source page: https://science.nasa.gov/resource/mars-planet-globe/

Source image: https://assets.science.nasa.gov/dynamicimage/assets/science/psd/mars/downloadable_items/3/7/37983_mars-globe-valles-marineris-enhanced.jpg

Transformation: JPEG converted to a 600 × 600 PNG.

Replacement SHA-256:
`642e81d8ebd94c3bee23cfe81c9847ab2f11d801d8d531e73cb4f467a7a8a481`

Credit: NASA/JPL-Caltech.

The image is credited separately from the MIT-licensed original ARES software. NASA endorsement is neither claimed nor implied.
